<?php

session_start();
include 'config/database.php';
include_once "object/product.php";
include_once "object/pro_image.php";
$database=new Database();
$db = $database->getConnection();

$product=new Product($db);
$product_image=new ProductImage($db);
$page_title = "Check out";
include 'layout_header.php';

echo '<section class="hero-area">';
    echo '<div class="hero-post-slides owl-carousel">';

        // Single Hero Post 
        echo '<div class="single-hero-post bg-overlay">';
            // Post Image 
            echo '<div class="slide-img bg-img" style="background-image: url(img/bgspecial.jpg);"></div>';
            echo '<div class="container h-100">';
                echo '<div class="row h-100 align-items-center font-cursive">';
                    echo '<div class="col-12">';
                        //Post Content 
                        echo '<div class="hero-slides-content text-center">';
                            echo '<h2>Place Your Order</h2>';
                        echo '</div>';
                    echo '</div>';
                echo '</div>';
            echo '</div>';
        echo '</div>';
    echo '</div>';
echo '</section>';

if(count($_SESSION['cart'])>0){
    $id_arr = array();
    foreach($_SESSION['cart'] as $Pro_id=>$value){
        array_push($id_arr, $Pro_id);
    }
 
    $stmt=$product->readByIds($id_arr);
    $total=0;
    $item_count=0;
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
        extract($row);
        $quant=$_SESSION['cart'][$Pro_id]['quant'];
        $sub_total=$price*$quant;

        echo "<div class='container'>";
            echo "<div class='col-md-8'>";
 
                echo "<div class='product-name m-b-10px'><h4>{$Pro_name}</h4></div>";
                echo $quant>1 ? "<div>{$quant} items</div>" : "<div>{$quant} item</div>";
 
            echo "</div>";
 
            echo "<div class='col-md-4'>";
                echo "<h4>Rs " . number_format($price, 2, '.', ',') . "</h4>";
            echo "</div>";
            echo '<hr>';
        echo "</div>";
 
        $item_count += $quant;
        $total+=$sub_total;
    }
    echo "<div class='container text-right'>";
        echo "<div class='cart-row'>";
            if($item_count>1){
                echo "<h4 class='m-b-10px'>Total ({$item_count} items)</h4>";
            }else{
                echo "<h4 class='m-b-10px'>Total ({$item_count} item)</h4>";
            }
            echo "<h4>Rs " . number_format($total, 2, '.', ',') . "</h4>";
            echo "<a href='ordernow.php' class='btn btn-lg btn-success m-b-10px'> Place Order";
            echo "</a>";
        echo "</div>";
    echo "</div>";
 
}
 
else{
    echo "<div class='col-md-12'>";
        echo "<div class='alert alert-danger'>";
            echo "No products found in your cart!";
        echo "</div>";
    echo "</div>";
}
 
include 'layout_footer.php';
?>