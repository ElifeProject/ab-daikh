<?php
include_once "config/core.php";
$page_title="Index";
$require_login=true;
include_once "login_checker.php";
include_once 'layout_header.php';
echo "<div class='col-md-12>";
     $action = isset($_GET['action']) ? $_GET['action'] : "";
     if($action=='login_success'){
        echo "<div class='alert alert-info'>";
            echo"<strong>Hello" . $_SESSION['firstname'] . ", welcome!</strong>";
        echo"</div>";
     }
     else if($action=='already_logged_in'){
        echo "<div class='alert alert-info'>";
            echo"<strong>Already logged in !!!!</strong>";
        echo"</div>";
     }
include_once 'layout_footer.php';
?>
