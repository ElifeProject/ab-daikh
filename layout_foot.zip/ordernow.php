<?php
session_start();
session_destroy();
 
// set page title
$page_title="Thank You!";
include_once 'layout_header.php';

echo '<section class="hero-area">';
    echo '<div class="hero-post-slides owl-carousel">';

        // Single Hero Post 
        echo '<div class="single-hero-post bg-overlay">';
            // Post Image 
            echo '<div class="slide-img bg-img" style="background-image: url(img/bgspecial.jpg);"></div>';
            echo '<div class="container h-100">';
                echo '<div class="row h-100 align-items-center font-cursive">';
                    echo '<div class="col-12">';
                        //Post Content 
                        echo '<div class="hero-slides-content text-center">';
                            echo '<h2>Your Order Has Placed</h2>';
                            echo '<p>Order will be delivered in 2 days.</p>';
                        echo '</div>';
                    echo '</div>';
                echo '</div>';
            echo '</div>';
        echo '</div>';
    echo '</div>';
echo '</section>';
 
echo "</div>";
include_once 'layout_footer.php';
?>