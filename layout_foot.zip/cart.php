<?php
// start session
session_start();
include 'config/database.php';
include_once "object/product.php";
include_once "object/pro_image.php";
$database=new Database();
$db = $database->getConnection();

$product=new Product($db);
$product_image=new ProductImage($db);

$page_title="Cart";
include 'layout_header.php';

echo '<section class="hero-area">';
    echo '<div class="hero-post-slides owl-carousel">';

        // Single Hero Post 
        echo '<div class="single-hero-post bg-overlay">';
            // Post Image 
            echo '<div class="slide-img bg-img" style="background-image: url(img/bgspecial.jpg);"></div>';
            echo '<div class="container h-100">';
                echo '<div class="row h-100 align-items-center font-cursive">';
                    echo '<div class="col-12">';
                        //Post Content 
                        echo '<div class="hero-slides-content text-center">';
                            echo '<h2>Your Cart</h2>';
                        echo '</div>';
                    echo '</div>';
                echo '</div>';
            echo '</div>';
        echo '</div>';
    echo '</div>';
echo '</section>';

$action= isset($_GET['action']) ? ($_GET['action'] ): "";
echo "<div class='col-md-12'>";
    if($action=='removed'){
        echo "<div class='alert alert-info'>";
            echo "Product was removed from your cart!";
        echo "</div>";
    }
    echo "</div>"; 
if(count($_SESSION['cart'])>0){
    $id_arr = array();
    foreach ($_SESSION['cart'] as $Pro_id=>$value){
        array_push($id_arr, $Pro_id);
    }
    $stmt=$product->readByIds($id_arr);
    $total=0;
    $item_count=0;
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
        extract($row);
        $quant=$_SESSION['cart'][$Pro_id]['quant'];
        $sub_total=$price*$quant;
        echo "<div class='container'>";
            echo "<div class='col-md-8'>";
 
                echo "<div class='product-name m-b-10px'><h4>{$Pro_name}</h4></div>";
                echo "<form class='update-quant-form'>";
                    echo "<div class='product-id' style='display:none;'>{$Pro_id}</div>";
                    echo "<div class='input-group'>";
                        echo "<div class='product-name m-b-10px'><h4>quantity: {$quant}</h4></div>";
                            echo "</span>";
                    echo "</div>";
                echo "</form>";
 
                // delete from cart
                echo "<a href='remove_item.php?Pro_id={$Pro_id}' class='btn btn-default'>";
                    echo "Delete";
                echo "</a>";
            echo "</div>";
 
            echo "<div class='col-md-4'>";
                echo "<h4> Rs " .number_format($price, 2, '.', ','). "</h4>";
            echo "</div>";
            echo "<hr>";
        echo "</div>";
        
        $item_count += $quant;
        $total+=$sub_total;
    }
    echo "<div class='col-md-8'></div>";
    echo "<div class='container'>";
        echo "<div class='cart-row text-right'>";
            echo "<h4 class='m-b-10px'>Total ({$item_count} items)</h4>";
            echo "<h4>Rs " .number_format($total,2,'.',',')."</h4>";
            echo "<a href='check_out.php' class='btn btn-success m-b-10px'>";
                echo "<span class='glyphicon glyphicon-shopping-cart'></span> Proceed to Checkout";
            echo "</a>";
        echo "</div>";
    echo "</div>";
 
}
else{
    echo "<div class='col-md-12'>";
        echo "<div class='alert alert-danger'>";
            echo "No products found in your cart!";
        echo "</div>";
    echo "</div>";
}
include 'layout_footer.php';
?>