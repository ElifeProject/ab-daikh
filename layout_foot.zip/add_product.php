<?php
$page = isset($_GET['page']) ? ($_GET['page']) : 1;
$records_per_page = 10;
$from_record_num = ($records_per_page * $page) - $records_per_page;
include_once '../config/database.php';
include_once '../object/product.php';
include_once '../object/category.php';
$database = new Database();
$db = $database->getConnection();
$product = new Product($db);
$category = new Category($db);
$page_title="Add Product";
include_once "layout_head.php";
if($_POST){
    $product->Pro_name=$_POST['Pro_name'];
    $product->price=$_POST['price'];
    $product->cat_id=$_POST['Catagory_id'];
    if($product->create()){
        echo "<div class ='alert alert-success'> Product was created successfully </div>";
    }
    else{
        echo "<div class ='alert alert-danger'> Sorry! product cannot be created </div>";
    }
}

include_once "layout_foot.php";

?>


