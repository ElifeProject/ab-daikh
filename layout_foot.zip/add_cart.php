<?php

session_start();
 
$Pro_id = isset($_GET['Pro_id']) ? $_GET['Pro_id'] : "";
$quant = isset($_GET['quant']) ? $_GET['quant'] : 1;
$page = isset($_GET['page']) ? $_GET['page'] : 1;
echo "<div class='col-md-12'>";
    if($action=='added'){
        echo "<div class='alert alert-info'>";
            echo "Product was added to your cart!";
        echo "</div>";
    }
    if($action=='exists'){
        echo "<div class='alert alert-info'>";
            echo "Product already exists in your cart!";
        echo "</div>";
    }
echo "</div>";
$quant=$quant<=0 ? 1 : $quant;
 
// add new item on array
$cart_item=array(
    'quant'=>$quant
);
if(!isset($_SESSION['cart'])){
    $_SESSION['cart'] = array();
}
if(array_key_exists($Pro_id, $_SESSION['cart'])){
    header('Location: cart.php?action=exists&Pro_id=' . $Pro_id .'&page='. $page);
}
 
// else, add the item to the array
else{
    $_SESSION['cart'][$Pro_id]=$cart_item;
    header('Location: cart.php?action=added&page=' . $page);
	}

?>