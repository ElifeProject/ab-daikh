<?php
if(!isset($_SESSION['cart']))
{
    $_SESSION['cart']=array();
}


 echo '<section class="our-services-area bg-gray section-padding-100 font-cursive">';
 echo '<div class="container">';
 echo '<div class="row">';
    echo '<div class="col-12">';
        // Section Heading 
            echo '<div class="section-heading text-center">';
                echo '<h2>PRODUCTS</h2>';
            echo '</div>';
        echo '</div>';
    echo '</div>';
echo '<div class="row">';
while($row=$stmt -> fetch(PDO::FETCH_ASSOC))
    {
    extract ($row);

    echo "<div class='col-md-4 col-sm-12'>";
        //echo"<div class = 'Product-id display-none'> {$Pro_id} </div>";
        echo"<a href='product.php?Pro_id = {$Pro_id}'class='product-link'>";
            $product_image->Product_id=$Pro_id;
            $stmt_product_image=$product_image->readFirst();
            //echo "$row->cat_id";
            //if form submitted
            include_once 'config/database.php';
            include_once 'object/product.php';
            include_once "object/category.php";
            $database = new Database();
            $db = $database->getConnection();

            $product = new Product($db);
            $category = new Category($db);
            $try = $product->readOne();
            //echo "$cat_id";
            //if ($cat_id==2){
            //echo "$Pro_id";
            $idd = $Pro_id;
            //echo "$idd";
            while ($row_product_image = $stmt_product_image->fetch(PDO::FETCH_ASSOC)){
                echo "<div class='m-b-10px'>";
                //echo "$Pro_id";
                if ($idd <= 332){
                    echo "<img src='uploads/img/{$row_product_image['image_name']}' class='w-30-pct img-size' />";
                }

                //echo "</div>";
            }
            //echo "$idd";
                if ($idd > 332){
                    echo "<div class='m-b-10px'>";
                    //echo "$idd";
                    echo "<img src='uploads/img/logo.png' class='w-30-pct' class='w-30-pct'/>";
                }
                echo "</div>";
 
            // product name
            echo "<div class='product-name mt-10'><h4>{$Pro_name}</h4></div>";
            echo "<div class='product-name mt-10'><h4>Rs " . number_format($price, 2, '.', ',') . "</h4></div>";
        echo "</a>";
 
        // add to cart button
        echo "<div class='m-b-10px'>";
            if(array_key_exists($Pro_id, $_SESSION['cart'])){
                echo "<a href='cart.php' class='btn btn-success w-100-pct'>";
                    echo "Add to  Cart";
                echo "</a>";
            }else{
                echo "<a href='add_cart.php?Pro_id={$Pro_id}&page={$page}' class='btn btn-primary w-30-pct'>Add to Cart</a>";
            }
        echo "</div>";
        echo "<br>";
    
    echo "</div>";

//}
}
echo "</div>";
echo "</div>";
echo "</section>";

include_once "paging.php";
?>