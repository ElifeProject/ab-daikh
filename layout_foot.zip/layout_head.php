<?php
$_SESSION['cart']=isset($_SESSION['cart']) ? $_SESSION['cart'] : array();
?>
<!DOCTYPE html>
<html lang="en">
<head>
 
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
 
    <title><?php echo isset($page_title) ? $page_title : "ELIFE"; ?></title>
 
    <!-- Latest compiled and minified Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />
   
    <!-- our custom CSS -->
    <link rel="stylesheet" href="css/custom.css" />
    <link rel="stylesheet" href="style.css" />
 
</head>
<body>
 
    <!-- navbar -->
<div class="navbar navbar-default navbar-static-top" role="navigation">
    <div class="container">
 
        <div class="navbar-header">
            <a class="navbar-brand" href="index.php"><img src="uploads/img/logo.png" style="width: 50px;"></a>
        </div>
                <li><a href="E-Life_Computer_Accessories.php">Computer Peripherals</a></li>   
                <li><a href="Project_Accessories.php">Project Accessories</a></li>
                <li><a href="E-Life_Book_Store.php">Book Store</a></li>
                <li><a href="Stationary_Store.php">Stationary Store</a></li>
                <li><a href="E-Life_Grocery_Store.php">Grocery Store</a></li>           
                <li><a href="Men's_Fashion.php">Men's Fashion</a></li>
                <li><a href="Women's_Fashion.php">Women's Fashion</a></li> 
                <li><a href="E-Life_Special.php">E-Life Special</a></li>
 
                <li <?php echo $page_title=="Cart" ? "class='active'" : ""; ?> >
                    <a href="cart.php">
                        <?php
                        // count products in cart
                        $cart_count=count($_SESSION['cart']);
                        ?>
                        Cart <span class="badge" id="comparison-count"><?php echo $cart_count; ?></span>
                    </a>
                </li>
            </ul>
 
        </div><!--/.nav-collapse -->
 
    </div>
</div>
<!-- /navbar -->
 
    <!-- container -->
    <div class="container">
        <div class="row">
 
        <div class="col-md-12">
            <div class="page-header">
                <h1><?php echo isset($page_title) ? $page_title : "ELIFE"; ?></h1>
            </div>
        </div>