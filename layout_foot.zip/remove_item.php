<?php

session_start();
$Pro_id = isset($_GET['Pro_id']) ? $_GET['Pro_id'] : "";
$Pro_name = isset($_GET['Pro_name']) ? $_GET['Pro_name'] : "";
unset($_SESSION['cart'][$Pro_id]);
header('Location:cart.php?action=removed&Pro_id=' . $Pro_id);

?>