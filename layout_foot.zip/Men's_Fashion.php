<?php
// start session
session_start();
include 'config/database.php';
include_once 'object/product.php';
include_once 'object/pro_image.php';
$database=new Database();
$db=$database->getConnection();

$product= new Product($db);
$product_image= new ProductImage($db);
$action = isset($_GET['action']) ? $_GET['action']: "";
// for pagination purposes
$page= isset($_GET['page']) ? ($_GET['page']) :1; 
$records_per_page=10;
$from_record_num=($records_per_page * $page) - $records_per_page;
$page_title="Men's_Fashion";
$sum = 0;
$arrs = array();
$stmt = $product->countbyid();
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
    extract($row);
        if ($cat_id== 6){
        $arrs[] = $Pro_id;
        $sum = $sum + 1;
    }
}
//echo "string";
//echo "$sum";
include 'layout_header.php';

echo '<section class="hero-area">';
    echo '<div class="hero-post-slides owl-carousel">';

        // Single Hero Post 
        echo '<div class="single-hero-post bg-overlay">';
            // Post Image 
            echo '<div class="slide-img bg-img" style="background-image: url(img/menfashion-bg.jpg);"></div>';
            echo '<div class="container h-100">';
                echo '<div class="row h-100 align-items-center font-cursive">';
                    echo '<div class="col-12">';
                        //Post Content 
                        echo '<div class="hero-slides-content text-center">';
                            echo '<h2>E-Life Mens Fashion </h2>';
                            echo '<p>Fashion is a language that creates itself in clothes to interpret reality. Dressing well is a form of good manners. You can get latest collection on E-Life Mens Fashion</p>';
                        echo '</div>';
                    echo '</div>';
                echo '</div>';
            echo '</div>';
        echo '</div>';
    echo '</div>';
echo '</section>';

 echo "<div class='col-md-12'>";
    if($action=='added'){
        echo "<div class='alert alert-info'>";
            echo "Product was added to your cart!";
        echo "</div>";
    }
    if($action=='exists'){
        echo "<div class='alert alert-info'>";
            echo "Product already exists in your cart!";
        echo "</div>";
    }
echo "</div>";
$stmt=$product->readdata($arrs,$from_record_num, $records_per_page);
$num = $stmt->rowCount();
 
// if products retrieved were more than zero
if($num>0){
    $page_url="Men's_Fashion.php?";
    $t_rows=$sum;
   // echo "$t_rows";
    include_once 'read_prod.php';
}
else{
    echo "<div class='col-md-12'>";
        echo "<div class='alert alert-danger'>No products found.</div>";
    echo "</div>";
}
include_once 'layout_footer.php';
?>